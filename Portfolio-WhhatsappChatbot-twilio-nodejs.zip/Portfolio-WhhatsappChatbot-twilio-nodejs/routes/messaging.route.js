const express = require("express");
const MessagingResponse = require('twilio').twiml.MessagingResponse;
const bodyParser = require('body-parser');
var qs = require('qs');


// const { MessagingResponse } = require('twilio').twiml;

const messageRouter = express.Router();

messageRouter.use(bodyParser.urlencoded({ extended: false }));



var accountSid = "AC*********************"; // Your Account SID from www.twilio.com/console
var authToken = "1c******************"; // Your Auth Token from www.twilio.com/console

var twilio = require("twilio");
var client = new twilio(accountSid, authToken);

messageRouter.post("/whatsapp", (req, res) => {
  messageControllers.messageController(req, res);
});

messageRouter.post("/results", (req, res) => {
  //messageControllers.messageStatus(req, res);
  console.log(req.body);
  res.json({ message: "received" });
});

messageRouter.post("/incoming", (req, res) => {
  console.log(req.body);
  res.json({ message: "received" });
  // messageControllers.messageStatus(req, res);
});

messageRouter.post("/sendToPhone", (req, res) => {
 
  client.messages
  .create({
    body: req.body.message,
    from: "whatsapp:+14155238886", // Text this number
    to: "whatsapp:"+req.body.number, // From a valid Twilio number
  })
  .then((message) => console.log(message.sid))
  .catch((err) => console.log(err))


res.json({ message: "success" });
});


messageRouter.post('/reply', (req, res) => {
   const twiml = new MessagingResponse();
//console.log(qs.parse(req).body);
  // Handle incoming message
  const incomingMsg = req.body.Body.toLowerCase();
  let responseMsg = '';
console.log(typeof(incomingMsg));
  // Your logic to generate response based on incomingMsg
  // Example:

  switch (incomingMsg) {
    case '1': responseMsg = 'Your Credit Score is:';
      break;
    case '2': responseMsg = 'FirstCentral is a credit risk management...';
      break;
    case '3': responseMsg = 'You can speak to our client support stafff on this number';
      break;
    case '4': responseMsg = 'Integrate our API by simply connecting to ...';
      break;
    default: responseMsg = 'Hi there! i\'m Joe your Virtual Assistant. \nHow can I help you? \nSend 1 to check free score. \nSend 2 to get information about our services. \nSend 3 to contact our client support team. \nSend 4 for information about integratinng your business'; 
  
  }

  // Send response
  twiml.message(responseMsg);

  res.writeHead(200, { 'Content-Type': 'text/xml' });
  res.end(twiml.toString());
});

module.exports = messageRouter;
